import pyautogui as pag
import time as t
import os

i = 0
while True:
    text = str(input("Enter text: "))
    if len(text) != 0:
        break
    else:
        os.system("cls")
        print("Error! You must enter the value!")
while True:
    try:
        again = int(input("Enter the number of repetitions: "))
        break
    except ValueError:
        os.system("cls")
        print("Error! You can only enter a number!")
while True:
    try:
        timing = float(input("Enter timing: "))
        break
    except ValueError:
        os.system("cls")
        print("Error! You can only enter a number!")

t.sleep(5)

while not i == again:
    pag.write(text)
    pag.hotkey("Enter")
    t.sleep(timing)
    i += 1