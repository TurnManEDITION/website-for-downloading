import java.util.Scanner;


class Translator {
    public static void main(String args[]) {
        System.out.print("\033[H\033[J");
        Scanner input = new Scanner(System.in);
        while (true) {
            System.out.print("|< Please select the transfer method:\n" +
                    "|< \t1 - Text >ASCII> Binary\n" +
                    "|< \t2 - Text >ASCII> Octal\n" +
                    "|< \t3 - Text >ASCII> Hex\n\n" +
                    "|< \t4 - Binary >ASCII> Text\n" +
                    "|< \t5 - Octal >ASCII> Text\n" +
                    "|< \t6 - Hex >ASCII> Text\n|> ");
            String answer = input.nextLine();
            if (answer.equals("1") | answer.equals("2") | answer.equals("3")) {
                System.out.print("\033[H\033[J");
                text_ascii_numsys(input, answer);
            } else if (answer.equals("4") | answer.equals("5") | answer.equals("6")) {
                System.out.print("\033[H\033[J");
                numsys_ascii_text(input, answer);
            } else {
                System.out.print("\033[H\033[J");
                System.out.println("|< There is no such method, please try again.");
            }
        }
    }
    /// text > ascii > numsys
    private static void text_ascii_numsys(Scanner input, String answer) {
        String sys = "";
        if (answer.equals("1")) {sys = "Binary";}
        else if (answer.equals("2")) {sys = "Octal";}
        else if (answer.equals("3")) {sys = "Hex";}
        String var = ""; /// Variable
        String ascii = "";
        System.out.println("|< Please enter the text.");
        String text = input.nextLine();
        System.out.print("\033[H\033[J");
        char[] chars_text = text.toCharArray();
        for (int i = 0; i != text.length(); i++) {
            ascii += String.valueOf((int) chars_text[i]) + " ";
        }
        String[] chars_ascii = ascii.split(" ");
        for (int i = 0; i != text.length(); i++) {
            if (sys.equals("Binary")) {
                var += Integer.toBinaryString(Integer.parseInt(chars_ascii[i])) + " "; /// Variable
            } else if (sys.equals("Octal")) {
                var += Integer.toOctalString(Integer.parseInt(chars_ascii[i])) + " "; /// Variable
            } else if (sys.equals("Hex")) {
                var += Integer.toHexString(Integer.parseInt(chars_ascii[i])) + " "; /// Variable
            }

        }
        System.out.println("Method \"Text >ASCII> " + sys + "\"\n"); /// Type
        System.out.println("Text: \n" + text);
        System.out.println("ASCII: \n" + ascii);
        System.out.println(sys + ": \n" + var + "\n\n"); /// Type/Variable
    }
    /// numsys > ascii > text
    private static void numsys_ascii_text(Scanner input, String answer) {
        String sys = "";
        int num_sys = 0;
        if (answer.equals("4")) {sys = "Binary"; num_sys = 2;}
        else if (answer.equals("5")) {sys = "Octal"; num_sys = 8;}
        else if (answer.equals("4")) {sys = "Hex"; num_sys = 16;}
        String text = "";
        String ascii = "";
        System.out.println("|< Please enter the " + sys + " code."); /// Type
        String var = input.nextLine(); /// Variable
        System.out.print("\033[H\033[J");
        String[] chars = var.split(" "); /// Variable
        for (int i = 0; i != chars.length; i++) {
            ascii += Integer.parseInt(chars[i], num_sys) + " ";
        }
        String[] chars_ascii = ascii.split(" ");
        for (int i = 0; i != chars.length; i++) {
            text += Character.toString((char) Integer.parseInt(chars_ascii[i]));
        }
        System.out.println("Method \"" + sys + " >ASCII> Text\"\n"); /// Type
        System.out.println(sys + ": \n" + var); /// Type/Variable
        System.out.println("ASCII: \n" + ascii);
        System.out.println("Text: \n" + text + "\n\n");
    }
}