from func import *


settings = [False, False, False]
i = 0

while not i == len(settings):
    while not i == len(settings):
        if i == 0: set = "letters"
        if i == 1: set = "digits"
        if i == 2: set = "symbols"
        answer = str(input(f"Include {set} in the password?(Y/n): "))
        os.system("cls")
        if answer.lower() == "y":
            settings[i] = True 
            break
        elif answer.lower() == "n": break 
    i += 1

quantity = 0
while not 0 < quantity <= 4196:
    quantity = int(input("Enter the number of characters in the password: "))
    os.system("cls")

chars = sett(settings)
password = gen_pass(chars, quantity)
pyperclip.copy(password)
print(f"{password}\nPassword copied!")
