import os, random, string, pyperclip

def gen_pass(chars, quantity):
    i = 0
    password = ""
    while not quantity == i:
        password += random.choice(chars)
        i += 1
    return password


def sett(settings):
    letters = string.ascii_letters
    digits = string.digits
    symbols = string.punctuation

    if settings == [False, False, False]:
        settings[0] = True 
        settings[1] = True 
        settings[2] = True
    
    chars = ""
    if settings[0] == True: chars += letters
    if settings[1] == True: chars += digits
    if settings[2] == True: chars += symbols
    return chars